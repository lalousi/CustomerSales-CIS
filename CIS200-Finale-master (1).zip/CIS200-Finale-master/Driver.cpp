#include "store.h"
#include <iostream>
#include <string>

using namespace std;

int main() {

	store techStore(4,20,2022);
	techStore.addProduct("Laptop", 0, 500, 100);
	techStore.addProduct("TV", 1, 350, 120);
	techStore.addProduct("Desktop", 2, 750, 68);
	techStore.addProduct("Monitor", 3, 260, 300);
	techStore.addProduct("Keyboard", 4, 50, 500);
	techStore.addProduct("Mouse", 5, 40, 700);
	techStore.addProduct("Smartphone", 6, 950, 1000);
	techStore.addProduct("Smartwatch", 7, 280, 900);
	techStore.addProduct("Tablet", 8, 300, 500);
	techStore.addProduct("Headphones", 9, 85, 1200);
	techStore.addProduct("Charger", 10, 55, 2000);
	techStore.addProduct("Speakers", 11, 75, 1300);
	techStore.addProduct("Game Console", 12, 500, 200);
	techStore.addProduct("Video Game", 13, 60, 4000);
	techStore.addProduct("Smartlights", 14, 80, 5000);
	techStore.addProduct("Router", 15, 90, 350);
	techStore.addProduct("Camera", 16, 600, 1020);

	string firstCustomer;

	cout << "Hello. Welcome to our store." << endl;
	cout << endl;

	int userChoice;
	do {
		cout << "What would you like to do at our store today? (-1 to exit) " << endl;
		cout << "=====================================================" << endl;
		cout << "0: Find a new customer (Do this upon startup) " << endl;
		cout << "1: Display all of the store's customers " << endl;
		cout << "2: Advance the date by 1 day " << endl;
		cout << "3: Advance the date by 1 month " << endl;
		cout << "4: Advance the date by 1 year " << endl;
		cout << "5: Display today's date " << endl;
		cout << "6: Display All Products " << endl;
		cout << "7: Check a certain product's availability " << endl;
		cout << "8: Purchase a certain product " << endl;
		cout << "9: Return a certain product " << endl;
		cout << "10: Look at a certain customer's receipts " << endl;
		cout << "11: Look at all customer receipts " << endl;
		cout << "=====================================================" << endl;
		cout << endl;
		cin >> userChoice;
		cout << endl;
		switch (userChoice) {
		case 0:
			techStore.addCustomer();
			cout << endl;
			break;
		case 1:
			techStore.listAllCustomers();
			cout << endl;
			break;
		case 2:
			techStore.advanceDay();
			cout << "The date was successfully advanced by 1 day. " << endl;
			cout << endl;
			break;
		case 3:
			techStore.advanceMonth();
			cout << "The date was successfully advanced by 1 month. " << endl;
			cout << endl;
			break;
		case 4:
			techStore.advanceYear();
			cout << "The date was successfully advanced by 1 year. " << endl;
			cout << endl;
			break;
		case 5:
			techStore.displayDate();
			cout << endl;
			break;
		case 6:
			techStore.displayAllProducts();
			cout << endl;
			break;
		case 7:
			techStore.searchForProduct();
			cout << endl;
			break;
		case 8:
			techStore.makePurchase();
			cout << endl;
			break;
		case 9:
			techStore.returnProduct();
			cout << endl;
			break;
		case 10:
			techStore.displayCustomerReceipt();
			cout << endl;
			break;
		case 11:
			techStore.displayAllReceipts();
			cout << endl;
			break;
		}


	} while (userChoice != -1);

	cout << "Thank you. Have a wonderful day." << endl;
	return 22;
}