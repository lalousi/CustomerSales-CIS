#include "store.h"
#include <iostream>
#include <string>
#include <vector>

using namespace std;


store::store() {
	month = 1;
	day = 1;
	year = 1;
	inventory.resize(0);
	storeCustomers.resize(0);
}

store::store(int userMonth, int userDay, int userYear) {
	month = userMonth;
	day = userDay;
	year = userYear;
	inventory.resize(0);
	storeCustomers.resize(0);
}

void store::advanceDay() {

	// If the last day of the month is the 31st, when advancing past 31, the day goes back to 1 //
	if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) {
		if (day >= 31) {
			day = 1;
		}
		else {
			day += 1;
		}
	}
	// If the last day of the month is the 30th, when advancing past 30, the day goes back to 1 //
	else if (month == 4 || month == 6 || month == 9 || month == 11) {
		if (day >= 30) {
			day = 1;
		}
		else {
			day += 1;
		}
	}
	// If the month is February, when advacing past 28 (or 29 for leap year), the day goes back to 1 //
	else if (month == 2) {
		if (year % 4 == 0) {
			if (day >= 29) {
				day = 1;
			}
			else {
				day += 1;
			}
		}
		else {
			if (day >= 28) {
				day = 1;
			}
			else {
				day += 1;
			}
		}
	}
}

void store::advanceMonth() {
	// If the month is January through November, go to the next month //
	if (month > 0 && month < 12) {
		month += 1;
	}
	// If it is December, go to January //
	else {
		month = 1;
	}
}

void store::advanceYear() {
	year += 1;
}

void store::setTime(int userDay, int userMonth, int userYear) {
	day = userDay;
	month = userMonth;
	year = userYear;
}

int store::getCurrentDay() {
	return day;
}

int store::getCurrentMonth() {
	return month;
}

int store::getCurrentYear() {
	return year;
}

void store::displayDate() {
	cout << "Today's current date: " << month << "/" << day << "/" << year << endl;
}

void store::addProduct(string userName, int userID, double userPrice, int userAmount) {
	product newProduct;
	newProduct.name = userName;
	newProduct.id = userID;
	newProduct.price = userPrice;
	newProduct.amount = userAmount;
	inventory.push_back(newProduct);
}

void store::displayAllProducts() {

	// If there are no items in inventory, send error message and go back to menu //
	if (inventory.size() == 0) {
		cout << "Apologies, there are no items in stock. Sorry about that." << endl;
	}
	// Otherwise, display iterate through the inventory and display all of the each product struct's data members //
	else {
		cout << "Here is the store's selection as of " << month << "/" << day << "/" << year << ":" << endl;
		for (int i = 0; i < inventory.size(); ++i) {
			cout << endl;
			cout << "================================" << endl;
			cout << "ID: " << inventory.at(i).id << endl;
			cout << "Name: " << inventory.at(i).name << endl;
			cout << "Price: $" << inventory.at(i).price << endl;
			cout << "Quantity: " << inventory.at(i).amount << endl;
			cout << "================================" << endl;
		}
	}
}
	
	void store::searchForProduct() {
		int searchID;

		// If inventory is empty, inform the user and send back to menu //
		if (inventory.size() == 0) {
			cout << "ERROR: No items are currently in stock. Sorry about that." << endl;
		}

		// Otherwise, iterate through the inventory and display the IDs and Names of every product in the vector //
		else {
			for (int i = 0; i < inventory.size(); ++i) {
				cout << "================================" << endl;
				cout << "ID: " << inventory.at(i).id << endl;
				cout << "Name: " << inventory.at(i).name << endl;
				cout << "================================" << endl;
				cout << endl;
			}

			// Prompt the user to choose which ID to search the quantity of //
			cout << endl;
			cout << "Please enter the ID of the item you would like to search for: ";
			cin >> searchID;
			cout << endl;

			// If the desired item's quantity is greater than 0, display all of that item's info //
			if (inventory.at(searchID).amount > 0) {
				cout << "The item you're searching for is still available. Here is the item's info:" << endl;
				cout << "================================" << endl;
				cout << "Product ID: " << searchID << endl;
				cout << "Name: " << inventory.at(searchID).name << endl;
				cout << "Price: $" << inventory.at(searchID).price << endl;
				cout << "Quantity: " << inventory.at(searchID).amount << endl;
				cout << "================================" << endl;
			}
			// If the desired item's quantity is 0, send error message and go back to menu //
			else {
				cout << "Apologies. The item you're searching for is no longer available." << endl;
			}
		}
	}


	void store::makePurchase() {
		// IDs to identify customer buying and desired product //
		int searchID;
		int customerID;

		// If no customeres, send back to menu to get customers first //
		if (storeCustomers.size() == 0) {
			cout << "Error: There are no customers in the store currently. Please find a customer first." << endl;
		}
		// If there are customers, prompt the user to pick which one will be purchasing //
		else {
			listAllCustomers();
			cout << endl;
			cout << "Please enter the ID of the customer making the purchase: ";
			cin >> customerID;
			cout << endl;

			// Prompt the user which product they want to buy //
			displayAllProducts();
			cout << endl;
			cout << "Please enter the ID of the item you would like to purchase: ";
			cin >> searchID;
			cout << endl;

			receipt newReceipt;
			// If desired item is in stock, create a new receipt, since it's a purchase update moneySpent and itemBought, use the current date for the receipt, update inventory of the store //
			if (inventory.at(searchID).amount > 0)
			{
				inventory.at(searchID).amount -= 1;
				newReceipt.day = getCurrentDay();
				newReceipt.month = getCurrentMonth();
				newReceipt.year = getCurrentYear();
				newReceipt.itemBought.push_back(inventory.at(searchID));
				newReceipt.moneySpent = inventory.at(searchID).price;
				storeCustomers.at(customerID).receipts.push_back(newReceipt);
				cout << "Thank you for your purchase. Here is your receipt: " << endl;
				cout << endl;
				cout << "================================" << endl;
				cout << "Date: " << getCurrentMonth() << "/" << getCurrentDay() << "/" << getCurrentYear() << endl;
				cout << "Item purchased: " << inventory.at(searchID).name << endl;
				cout << "Money spent: $" << inventory.at(searchID).price << endl;
				cout << "================================" << endl;
			}
			// If the desired item is not in stock, send back to menu.
			else
			{
				cout << inventory.at(searchID).name << " is no longer in stock." << endl;
			}
		}
	}

	void store::returnProduct() {
		int searchID;
		int customerID;

		// If there are no customers in the store, go back to the menu //
		if (storeCustomers.size() == 0) {
			cout << "ERROR: There are no customers in the store currently. Please find a customer first." << endl;
		}

		// If there are customers in the store, list all of them, choose which customer is returning, what they're returning, update inventory, and then display the receipt //
		else {
			// List all customers and enter the ID of the one making the return //
			listAllCustomers();
			cout << endl;
			cout << "Please enter the ID of the customer making the return: ";
			cin >> customerID;
			cout << endl;

			// Display all of the products and prompt the user to choose which one to return //
			displayAllProducts();
			cout << endl;
			cout << "Please enter the ID of the item you would like to return: ";
			cin >> searchID;
			cout << endl;
			
			// Create a new receipt, since it's a return update moneyReturned and itemReturned, use the current date for the receipt, update inventory of the store //
			receipt newReceipt;

			inventory.at(searchID).amount += 1;
			newReceipt.day = getCurrentDay();
			newReceipt.month = getCurrentMonth();
			newReceipt.year = getCurrentYear();
			newReceipt.itemReturned.push_back(inventory.at(searchID));
			newReceipt.moneyReturned += inventory.at(searchID).price;
			storeCustomers.at(customerID).receipts.push_back(newReceipt);

			// Code to display the receipt information //
			cout << "Thank you for your return. Here is your receipt: " << endl;
			cout << endl;
			cout << "================================" << endl;
			cout << "Date: " << getCurrentMonth() << "/" << getCurrentDay() << "/" << getCurrentYear() << endl;
			cout << "Item returned: " << inventory.at(searchID).name << endl;
			cout << "Money returned: $" << inventory.at(searchID).price << endl;
			cout << "================================" << endl;
		}
	}

void store::addCustomer() {

	// Prompt the user to enter their name, which will be pushed back to the storeCustomers vector of the store class //
	string inputName;
	cout << "Hello. Please enter your name: ";
	cin >> inputName;
	cout << "Thank you. Welcome to our store, " << inputName << "." << endl;
	cout << endl;
	customer newCustomer;
	newCustomer.name = inputName;
	storeCustomers.push_back(newCustomer);
}

void store::listAllCustomers() {

	// If there are no customers in the store, don't display and send back to menu //
	if ( storeCustomers.size() == 0 ) {
		cout << "ERROR: There are no customers in the store. Please find some first." << endl;
	}
	// Otherwise, display all customers in the storeCustomers vector, with IDs starting at 0 and moving up, etc. //
	else {
		cout << "Here is the list of all of the store's customers: " << endl;
		for (int i = 0; i < storeCustomers.size(); ++i) {
			cout << "================================" << endl;
			cout << "Customer ID " << i << ": " << storeCustomers.at(i).name << endl;
			cout << "================================" << endl;
			cout << endl;
		}
	}
}

void store::displayCustomerReceipt() {
	// If there are no customers in the store, send user back to menu //
	if (storeCustomers.size() == 0) {
		cout << "ERROR: There are no customers in the store. Please find some first." << endl;
	}
	// Otherwise, list all customers in the store and prompt which one will have their receipts shown //
	else {
		int customerID;
		listAllCustomers();
		cout << endl;
		cout << "Please enter the ID of the customer whose receipts to display: ";
		cin >> customerID;
		cout << endl;

		// Iterate through the index of each receipt of the desired customer //
		for (int j = 0; j < storeCustomers.at(customerID).receipts.size(); ++j) {
			// If there is no item in the itemReturned vector, then the current receipt is a purchase, so display the corresponding info from the receipt //
			if (storeCustomers.at(customerID).receipts.at(j).itemReturned.size() == 0) {
				cout << "================================" << endl;
				cout << "Date: " << storeCustomers.at(customerID).receipts.at(j).month << "/" << storeCustomers.at(customerID).receipts.at(j).day << "/" << storeCustomers.at(customerID).receipts.at(j).year << endl;
				cout << "Customer name: " << storeCustomers.at(customerID).name << endl;
				cout << "Item bought: " << storeCustomers.at(customerID).receipts.at(j).itemBought.at(0).name << endl;
				cout << "Money spent: $" << storeCustomers.at(customerID).receipts.at(j).moneySpent << endl;
				cout << "================================" << endl;
				cout << endl;
			}
			// If there are no item in the itemBought vector, then the current receipt is a return, so display the corresponding info from the receipt //
			else if (storeCustomers.at(customerID).receipts.at(j).itemBought.size() == 0) {
				cout << "================================" << endl;
				cout << "Date: " << storeCustomers.at(customerID).receipts.at(j).month << " / " << storeCustomers.at(customerID).receipts.at(j).day << " / " << storeCustomers.at(customerID).receipts.at(j).year << endl;
				cout << "Name: " << storeCustomers.at(customerID).name << endl;
				cout << "Item returned: " << storeCustomers.at(customerID).receipts.at(j).itemReturned.at(0).name << endl;
				cout << "Money returned: $" << storeCustomers.at(customerID).receipts.at(j).moneyReturned << endl;
				cout << "================================" << endl;
				cout << endl;
			}
		}
	}
}
	

void store::displayAllReceipts() {
	// iterator i to iterate each index of storeCustomers //
	int i = 0;

	// If there are no customers in the store, send back to menu //
	if (storeCustomers.size() == 0) {
		cout << "ERROR: There are no customers from the store. Please find a customer first. " << endl;
	}
	else {
		do {
			// iterator j to iterate each receipt of current index i storeCustomers //
			for (int j = 0; j < storeCustomers.at(i).receipts.size(); ++j) {
				// If no item in itemReturned, current receipt is a purhase, so display appropriate info //
				if (storeCustomers.at(i).receipts.at(j).itemReturned.size() == 0) {
					cout << "================================" << endl;
					cout << "Date: " << storeCustomers.at(i).receipts.at(j).month << "/" << storeCustomers.at(i).receipts.at(j).day << "/" << storeCustomers.at(i).receipts.at(j).year << endl;
					cout << "Customer name: " << storeCustomers.at(i).name << endl;
					cout << "Item bought: " << storeCustomers.at(i).receipts.at(j).itemBought.at(0).name << endl;
					cout << "Money spent: $" << storeCustomers.at(i).receipts.at(j).moneySpent << endl;
					cout << "================================" << endl;
					cout << endl;
				}
				// If no item is in itemBought, current receipt is a return, so display appropriate info //
				else if (storeCustomers.at(i).receipts.at(j).itemBought.size() == 0) {
					cout << "================================" << endl;
					cout << "Date: " << storeCustomers.at(i).receipts.at(j).month << "/" << storeCustomers.at(i).receipts.at(j).day << "/" << storeCustomers.at(i).receipts.at(j).year << endl;
					cout << "Name: " << storeCustomers.at(i).name << endl;
					cout << "Item returned: " << storeCustomers.at(i).receipts.at(j).itemReturned.at(0).name << endl;
					cout << "Money returned: $" << storeCustomers.at(i).receipts.at(j).moneyReturned << endl;
					cout << "================================" << endl;
					cout << endl;
				}
			}
			i++;
		} while (i < storeCustomers.size());
	}
}
