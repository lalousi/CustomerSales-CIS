#ifndef STORE_H
#define STORE_H
#endif

#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct product {
	int id = 0;
	string name = "N/A";
	double price = 0;
	int amount = 0;
};

struct receipt {
	int day = 1;
	int month = 1;
	int year = 1;
	vector<product> itemBought;
	vector<product> itemReturned;
	double moneySpent = 0;
	double moneyReturned = 0;
};

struct customer {
	string name;
	vector<receipt> receipts;
};
class store {
private:
	vector<product> inventory;
	vector<customer> storeCustomers;
	int month;
	int day;
	int year;
public:
	void addCustomer();
	void listAllCustomers();
	void displayCustomerReceipt();
	void displayAllReceipts();
	void displayAllProducts();
	void addProduct(string inputName, int inputID, double inputPrice, int inputAmount);
	void searchForProduct();
	void makePurchase();
	void returnProduct();
	void setTime(int userMonth, int userDay, int userYear);
	void advanceMonth();
	void advanceDay();
	void advanceYear();
	int getCurrentMonth();
	int getCurrentDay();
	int getCurrentYear();
	void displayDate();
	store();
	store(int userMonth, int userDay, int userYear);
};